"""Снимок уникальных лидов с заполнением из самых свежих дат отчёта."""

from __future__ import annotations

import logging
import time
from typing import Any, Callable

import pandas as pd

from src.client_names import abbreviate_client_name
from src.settings import col
from src.v2.exceedance_config import resolve_exceedance_columns

logger: logging.Logger = logging.getLogger("kanban.excel_v2.snapshot")

# Поля, которые берутся строго из строки с max «Дата отчета» (без fill-forward).
_LATEST_ROW_ONLY_KEYS: frozenset[str] = frozenset({"sales_method"})


def _empty_tokens(config: dict[str, Any]) -> set[str]:
    """Множество пустых текстовых значений."""
    raw: list[Any] = config.get("processing", {}).get("empty_stage_values", ["", "-", "nan", "None"])
    tokens: set[str] = {str(v).strip().casefold() for v in raw}
    tokens.update({"", "nan", "none", "null", "nat"})
    return tokens


def _series_as_text(series: pd.Series) -> pd.Series:
    """
    Строковое представление серии без FutureWarning от fillna на object dtype.
    Сначала StringDtype, затем fillna — без silent downcasting.
    """
    as_str: pd.Series = series.astype("string").fillna("").astype(str)
    return as_str.str.strip().str.casefold()


def _nonempty_mask(series: pd.Series, empty: set[str]) -> pd.Series:
    """Векторная маска непустых значений."""
    as_str: pd.Series = _series_as_text(series)
    return ~as_str.isin(empty)


def _first_nonempty_per_group(series: pd.Series, empty: set[str]) -> Any:
    """Первое непустое значение в серии (порядок строк уже по убыванию даты)."""
    mask: pd.Series = _nonempty_mask(series, empty)
    if not mask.any():
        return pd.NA
    return series.loc[mask.index[mask]].iloc[0]


def _first_nonempty_by_lead(
    work: pd.DataFrame,
    lead_src: str,
    src_col: str,
    empty: set[str],
) -> pd.Series:
    """
    Векторно: первое непустое значение по лиду (строки work уже отсортированы
    по убыванию даты отчёта). Быстрее groupby.apply на миллионах строк.
    """
    mask: pd.Series = _nonempty_mask(work[src_col], empty)
    nonempty: pd.DataFrame = work.loc[mask, [lead_src, src_col]]
    if nonempty.empty:
        return pd.Series(dtype=object)
    return nonempty.groupby(lead_src, sort=False)[src_col].first()


def snapshot_column_map(config: dict[str, Any]) -> dict[str, str]:
    """Ключ колонки config → заголовок Excel на листе уникальных ID."""
    raw: dict[str, Any] = config.get("output", {}).get("snapshot_columns") or {}
    return {str(k): str(v) for k, v in raw.items()}


def build_lead_snapshot(
    df: pd.DataFrame,
    config: dict[str, Any],
    *,
    progress: Any | None = None,
) -> pd.DataFrame:
    """
    Уникальные лиды с подтягиванием полей из самых свежих непустых строк.
    В снимке все поля под ключами config (lead_id, deal_id, …), не под Excel-именами.
    progress — опциональный ProgressReporter для heartbeat на длинных прогонах.
    """
    if df.empty:
        return pd.DataFrame()

    lead_src: str = col(config, "lead_id")
    report_col: str = col(config, "report_date")
    days_col: str = col(config, "days_on_stage")
    field_keys: list[str] = list(snapshot_column_map(config).keys())

    src_cols: set[str] = {lead_src, report_col, days_col}
    for key in field_keys:
        if key in config.get("columns", {}):
            src_cols.add(col(config, key))
    use_cols: list[str] = [c for c in src_cols if c in df.columns]

    t0: float = time.monotonic()
    _hb: Callable[[str], None]
    if progress is not None and hasattr(progress, "step"):
        _hb = lambda msg: progress.step(msg)
    else:
        _hb = lambda msg: logger.info("  … %s", msg)

    _hb(f"снимок: подготовка {len(df):,} строк, полей={len(field_keys)}")
    work: pd.DataFrame = df[use_cols].copy()
    work[report_col] = pd.to_datetime(work[report_col], errors="coerce")
    work = work.dropna(subset=[lead_src])
    work[lead_src] = work[lead_src].astype(str).str.strip()
    work = work.loc[work[lead_src] != ""]
    work = work.sort_values([lead_src, report_col], ascending=[True, False], kind="mergesort")
    _hb(f"снимок: сортировка готова ({time.monotonic() - t0:.0f} сек)")

    empty: set[str] = _empty_tokens(config)

    latest: pd.DataFrame = work.drop_duplicates(subset=[lead_src], keep="first")
    indexed: pd.DataFrame = latest[[lead_src]].set_index(lead_src)
    indexed.index.name = "lead_id"
    indexed["_report_date"] = latest[report_col].values
    if days_col in latest.columns:
        indexed["_days_on_stage"] = pd.to_numeric(latest[days_col], errors="coerce").values
    else:
        indexed["_days_on_stage"] = pd.NA

    total_fields: int = len(field_keys)
    for idx, key in enumerate(field_keys, start=1):
        if key not in config.get("columns", {}):
            continue
        src_col: str = col(config, key)
        if src_col not in work.columns:
            indexed[key] = pd.NA
            continue
        if key in _LATEST_ROW_ONLY_KEYS:
            # Строго из строки с max датой отчёта
            indexed[key] = latest.set_index(lead_src)[src_col]
        else:
            filled: pd.Series = _first_nonempty_by_lead(work, lead_src, src_col, empty)
            indexed[key] = filled.reindex(indexed.index)
        if progress is not None and hasattr(progress, "maybe_heartbeat"):
            progress.maybe_heartbeat(
                f"снимок: поле {idx}/{total_fields} «{key}» "
                f"({time.monotonic() - t0:.0f} сек)"
            )
        elif idx == 1 or idx == total_fields or idx % 3 == 0:
            _hb(
                f"снимок: поле {idx}/{total_fields} «{key}» "
                f"({time.monotonic() - t0:.0f} сек)"
            )

    result: pd.DataFrame = indexed.reset_index()

    if "client" in result.columns:
        result["client"] = result["client"].map(
            lambda v: abbreviate_client_name(v, config) if pd.notna(v) else v
        )

    logger.info("Снимок лидов: %s уникальных ID", f"{len(result):,}")
    return result.reset_index(drop=True)


def snapshot_to_export_frame(
    snapshot: pd.DataFrame,
    config: dict[str, Any],
    *,
    status_duration_columns: list[str] | None = None,
) -> pd.DataFrame:
    """
    Переименовывает ключи снимка в Excel-заголовки.
    """
    if snapshot.empty:
        return snapshot

    lead_label: str = col(config, "lead_id")
    mapping: dict[str, str] = snapshot_column_map(config)
    rename: dict[str, str] = {"lead_id": lead_label}
    for key, label in mapping.items():
        if key in snapshot.columns:
            rename[key] = label

    export_cols: list[str] = [lead_label] + [mapping[k] for k in mapping if k in snapshot.columns]
    renamed: pd.DataFrame = snapshot.rename(columns=rename)

    # Сроки по статусам — сразу после «Стадия работы с лидом»
    status_label: str = mapping.get("current_status", "")
    if status_duration_columns and status_label and status_label in export_cols:
        insert_at: int = export_cols.index(status_label) + 1
        for col_name in status_duration_columns:
            if col_name in renamed.columns and col_name not in export_cols:
                export_cols.insert(insert_at, col_name)
                insert_at += 1

    exc_cfg: dict[str, str] = resolve_exceedance_columns(config)
    extra_cols: list[str] = [
        exc_cfg["p80_norm"],
        exc_cfg["current_days"],
        exc_cfg["exceedance_flag"],
        exc_cfg["exceedance_days"],
    ]
    for col_name in extra_cols:
        if col_name in renamed.columns and col_name not in export_cols:
            export_cols.append(col_name)

    team_out: dict[str, Any] = config.get("team_files", {}).get("output_columns") or {}
    email_out: dict[str, Any] = (
        (config.get("manager_emails") or {}).get("output_columns") or {}
    )
    for block_name in ("lead", "deal"):
        block = team_out.get(block_name)
        if not isinstance(block, dict):
            continue
        for field_key in ("member_tab_number", "member", "role", "tb"):
            label = block.get(field_key)
            if label and label in renamed.columns and label not in export_cols:
                export_cols.append(str(label))
            if field_key == "member":
                email_block = email_out.get(block_name)
                if isinstance(email_block, dict):
                    for ek in ("email_alpha", "email_sigma"):
                        elabel = email_block.get(ek)
                        if elabel and elabel in renamed.columns and elabel not in export_cols:
                            export_cols.append(str(elabel))
        for label in block.values():
            if label in renamed.columns and label not in export_cols:
                export_cols.append(str(label))

    present: list[str] = [c for c in export_cols if c in renamed.columns]
    return renamed[present].copy()
