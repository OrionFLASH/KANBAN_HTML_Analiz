# Справочник config_excel_v2.json

Отдельная конфигурация для **Excel-only pipeline v2** (`run_excel.py`).  
Не связана с `config.json` / `run.py` (HTML+JSON). Общие модули (`excel_loader`, `filters`, `lead_tracker`, `aggregator`) читают те же ключи, что описаны в [CONFIG.md](CONFIG.md), если они присутствуют в `config_excel_v2.json`.

**Версия документа:** 2.5.0 (2026-09-10)

---

## Оглавление

1. [Запуск и пути](#1-запуск-и-пути)
2. [Карта корневых ключей](#2-карта-корневых-ключей)
3. [Фильтры v2](#3-фильтры-v2)
3.1. [Отсечение выбросов](#31-отсечение-выбросов-outlier_clipping)
4. [team_files](#4-team_files)
5. [output — листы и колонки](#5-output--листы-и-колонки)
5.1. [report_parts — два файла и пропуск расчётов](#report_parts)
5.2. [duration_matrix — матрицы сроков](#duration_matrix)
5.3. [status_duration_columns — сроки по статусам на «Уникальные ID»](#status_duration_columns)
5.4. [excel_format — даты, текст ID, light-листы](#excel_format)
6. [client_display](#6-client_display)
7. [Производительность](#7-производительность)
8. [Минимальный config](#8-минимальный-config)

---

## 1. Запуск и пути

```bash
python run_excel.py
# или
python -m src.v2.pipeline
```

| Ключ | Значение по умолчанию | Описание |
|------|----------------------|----------|
| `mode` | `"test"` | `"test"` → `paths.input_test`, `"prod"` → `paths.input_prod` |
| `paths.input_test` | `IN/TEST` | Тестовые Kanban + команды |
| `paths.input_prod` | `IN/PROD` | Prod-файлы |
| `paths.output` | `OUT/excel_v2` | Каталог отчётов |
| `paths.log` | `log` | Логи (`INFO_excel_v2_*`, `DEBUG_excel_v2_*`) |
| `test_files` | массив имён xlsx | Файлы Kanban для test |
| `prod_files` | массив имён xlsx | Файлы Kanban для prod |

**Выход — два Excel-файла** (см. [`report_parts`](#report_parts)):

| Часть | Имя файла | Листы |
|-------|-----------|--------|
| `analytics` | `{report_prefix}_analytics_{timestamp}.xlsx` | Нормативы, Статистика, все «Распределение сроков» |
| `detail` | `{report_prefix}_detail_{timestamp}.xlsx` | Уникальные ID, Свод по менеджеру, Свод ПрПр с отклонениями |

По умолчанию `report_prefix` = `kanban_excel_v2`, `timestamp_format` = `%Y%m%d_%H%M%S`. JSON **не** создаётся.

### Листы отчёта (`output.sheets`)

| Ключ config | Имя листа | Файл | Содержание |
|-------------|-----------|------|------------|
| `norms` | Нормативы | analytics | P20/P50/P80 по ТБ+группе+продукту+стадии; колонки отсечения выбросов **по каждой группе** |
| `statistics` | Статистика | analytics | Воронка фильтров + свод выбросов |
| `duration_matrix` | Распределение сроков | analytics | Матрица группа/продукт × дни; P20/P50/P80; «Всего»; порядок `by_volume` |
| `duration_matrix_by_group` | Распределение сроков (группы) | analytics | Дни ↑; группы А→Я; продукты по убыванию лидов |
| `duration_matrix_by_status` | Распределение сроков (статус) | analytics | Как основной + колонка «Текущий статус» после продукта |
| `duration_matrix_by_group_status` | Распред. сроков (группы+статус) | analytics | Раскладка по группам + статус |
| `leads` | Уникальные ID | detail | Снимок лидов, лидеры, **колонки сроков по каждому статусу**, норматив P80, превышение |
| `managers` | Свод по менеджеру | detail | Уникальные ФИО/ТН, число нарушений P80 |
| `violations` | Свод ПрПр с отклонениями | detail | Строка на каждое превышение |

---

## 2. Карта корневых ключей

| Ключ | Назначение |
|------|------------|
| `columns`, `required_column_keys`, `optional_column_keys` | Имена колонок Kanban (см. [CONFIG.md §4](CONFIG.md#4-колонки-excel-columns)) |
| `excel` | Лист Sheet1 с заголовком, openpyxl `read_only` |
| `processing` | Дедупликация, аудит, fallback сроков |
| `dates` | Парсинг дат |
| `duration_source` | `"columns"` (по умолчанию) или `"dates"` |
| `stage_analysis_mode` | `"status"` — только «Текущий статус» |
| `product_analysis_mode` | `"group_product"` |
| `percentiles` | `[20, 50, 80]` |
| `exceedance.percentile` | Порог превышения на лидах (по умолчанию `80`; должен входить в `percentiles`) |
| `aggregation.metrics` | `["days_on_stage"]` — только срок на стадии |
| `filters` | См. §3 |
| `outlier_clipping` | Отсечение выбросов срока перед нормативами, см. §3.1 |
| `team_files` | Файлы команд лида/сделки, см. §4 |
| `manager_emails` | CSV почт Альфа/Сигма по ТН (`IN/` + filename), см. §4 |
| `client_display` | Сокращение юрформ в «Клиент», см. §6 |
| `output` | Префикс, **report_parts**, листы, подписи, оформление Excel — §5 |
| `performance` | Workers, память, параллель этапов, см. §7 |
| `progress` | Консольный прогресс; `debug_detail` (default true) — тайминги подэтапов в DEBUG |
| `logging` | `logger_name: kanban_excel_v2` |
| `parallel_workers` | `0` = авто (CPU − reserve) |
| `excel_theme` | `"green_red"` — заливка колонок «Мин»/«Макс» |

Дополнительные колонки v2 (в `columns`; не все попадают в снимок):

| Ключ | Колонка Excel | В снимке «Уникальные ID»? |
|------|---------------|---------------------------|
| `client_id` | Идентификатор клиента | да (как **текст**) |
| `gosb` | ГОСБ | да |
| `source_deal_id` | ID сделки в исходной системе | **нет** (не выводится) |
| `tb_code` | Код ТБ | **нет** (не выводится) |

---

## 3. Фильтры v2

Все фильтры с `enabled: true` объединяются по **AND**.  
Формат — **универсальный** (см. ниже). Старые ключи (`value`, `contains*`, `exclude_*`) по-прежнему понимаются адаптером в `src/filters.py`.

> **Нет HTML/JSON:** в `config_excel_v2.json` **не используется** поле `html_slice` из `config.json`. В v2 действует только `enabled: true/false`.

### Универсальная схема

```json
"имя_фильтра": {
  "enabled": true,
  "column_key": "label",
  "column_keys": [],
  "action": "include",
  "match": "contains",
  "values": ["Стратегия 2 квартал 2026", "Стратегия 2 кватал 2026"],
  "values_mode": "any",
  "value_type": "string",
  "case_sensitive": false
}
```

| Поле | Значения | Смысл |
|------|----------|--------|
| `column_key` | ключ из `columns` | основная колонка |
| `column_keys` | массив ключей | доп. колонки; совпадение по **OR** |
| `action` | `include` \| `exclude` | оставить / убрать совпавшие строки |
| `match` | `equals` \| `contains` | целое поле / подстрока |
| `values` | массив | эталоны сравнения |
| `values_mode` | `any` \| `all` | достаточно одного / нужны все |
| `value_type` | `string` \| `number` \| `date` \| `auto` | приведение типа |
| `case_sensitive` | bool | для string |

Терминальные `action: exclude` применяются после inclusion (`filter_terminal_deal_stage_rows`).  
Пустые стадии (`processing.empty_stage_values`) **не** попадают под exclude.

### Текущий набор v2

| Имя | action | match | values | values_mode | value_type |
|-----|--------|-------|--------|-------------|------------|
| `efs_flag` | include | equals | `[1]` | any | number |
| `change_conditions` | include | equals | `[0]` | any | number |
| `strategy_label` | include | contains | `["Стратегия"]` | any | string (**вкл.**) |
| `strategy_label_2026` | include | contains | оба варианта «Стратегия 2 квар*тал* 2026» | any | string (`enabled: false`) |
| `strategy_label_and_2026` | include | contains | `["Стратегия", "2026"]` | **all** | string (`enabled: false`) |
| `current_status_activation` | include | contains | `["АКТИВАЦИЯ ПРОДУКТА"]` | any | string (`enabled: false`) |
| `exclude_current_otkaz` | exclude | contains | `["отказ"]` | any | string |
| `exclude_current_for_sale` | exclude | equals | `["К ПРОДАЖЕ"]` | any | string |
| `exclude_deal_otkaz` | exclude | contains | `["отказ"]` | any | string |
| `exclude_deal_zakryta` | exclude | contains | `["закрыта"]` | any | string |
| `exclude_deal_zaklyuchen` | exclude | contains | `["заключен"]` | any | string |
| `data_entry` | include | equals | `[0]` | any | number (`enabled: false`) |

По умолчанию из меток активен только `strategy_label` (подстрока «Стратегия»). Варианты `*_2026` и фильтр стадии «АКТИВАЦИЯ ПРОДУКТА» выключены — включаются в config при необходимости.

---

## 3.1. Отсечение выбросов (`outlier_clipping`)

Перед расчётом min/max/перцентилей в **каждой группе** агрегации (группа продукта + продукт + стадия [+ ТБ]) из выборки убираются нетипичные сроки. Снимок лидов и лист «Уникальные ID» **не** режутся — только нормативы / статистика.

```json
"outlier_clipping": {
  "enabled": true,
  "metric": "days_on_stage",
  "export_audit": true,
  "min_group_size": 5,
  "min_remaining": 3,
  "rules": [
    {
      "name": "global_max_500",
      "enabled": true,
      "scope": {},
      "mode": "range",
      "max_days": 500,
      "min_remaining": 3
    },
    {
      "name": "band_credits",
      "enabled": true,
      "scope": { "product_group": "Кредиты", "current_status": "В РАБОТЕ" },
      "mode": "range",
      "min_days": 2,
      "max_days": 500
    },
    {
      "name": "trim5",
      "enabled": true,
      "scope": {},
      "mode": "percentile_trim",
      "trim_lower_pct": 5,
      "trim_upper_pct": 5,
      "min_remaining": 5
    },
    {
      "name": "unique_days_10",
      "enabled": false,
      "scope": {},
      "mode": "unique_days_trim",
      "trim_lower_pct": 10,
      "trim_upper_pct": 10
    },
    {
      "name": "auto_iqr",
      "enabled": true,
      "scope": {},
      "mode": "iqr",
      "iqr_k": 1.5
    }
  ]
}
```

| Поле | Описание |
|------|----------|
| `enabled` | Вкл/выкл всего блока |
| `metric` | Колонка срока (`days_on_stage`) |
| `export_audit` | Колонки аудита на листе «Нормативы» |
| `min_group_size` | Минимум строк в группе для расчёта порогов `iqr` / `percentile_trim` |
| `min_remaining` | Минимум лидов после правила: если осталось бы меньше — правило **не применяется** (можно переопределить в `rules[].min_remaining`) |
| `rules[].name` | Имя для колонки «Отсечено: …» |
| `rules[].scope` | `{}` = все группы; иначе фильтр по `product_group` / `product` / `current_status` / `tb` (строка или массив) |
| `rules[].mode` | `range` \| `percentile_trim` \| `unique_days_trim` \| `iqr` |
| `rules[].min_remaining` | Опционально: порог «минимум лидов после» только для этого правила |
| `min_days` / `max_days` | Для `range`: отсечь срок `< min` или `> max` |
| `trim_lower_pct` / `trim_upper_pct` | Для `percentile_trim`: % квантилей снизу / сверху; для `unique_days_trim`: % от **числа уникальных сроков** слева / справа |
| `iqr_k` | Для `iqr`: множитель (обычно 1.5) |

#### `unique_days_trim` — отсечение по уникальным срокам

В группе берутся **разные значения дней**, по которым есть лиды (дни без лидов не считаются).  
Процент считается от **числа таких уникальных значений**, не от числа лидов.

Пример: 20 уникальных сроков `1, 20, 25, …, 80, 99`, `trim_lower_pct = trim_upper_pct = 10`  
→ `10% × 20 = 2` значения слева и 2 справа → отсекаются все лиды с днями `1`, `20` и `80`, `99`.  
Число уникальных значений после отсечения: `20 − 4 = 16`. Доля округляется **вниз** (`int`); если слева+справа ≥ всех уникальных — правило пропускается.

Правила применяются **по порядку**; на листе **«Статистика»**:

1. **Воронка фильтров**: по каждому активному фильтру / исключению — «До/После/Отсечено» для **строк** и **уникальных лидов**.
2. **Свод выбросов**: суммы колонок аудита по всем группам (и статус, если `outlier_clipping` выключен).

На листе **«Нормативы»** — обычная таблица по ТБ / группе / продукту / стадии (автофильтр, закрепление шапки) с колонками аудита по **каждой группе**: `До отсечения`, `После отсечения`, `Отсечено (всего)`, `Отсечено: <name>` (`export_audit: true`).

Чтобы колонки выбросов появились, нужно **`outlier_clipping.enabled: true`** и хотя бы одно правило с **`enabled: true`**.

В актуальном `config_excel_v2.json` блок **включён**; активным примером может быть `unique_days_trim` (остальные правила — с `enabled: false`).

**Реализация:** маска отсечения строится по Series с **тем же индексом**, что у группы после `groupby` (не через `ndarray` без индекса). Иначе на больших выборках возможен `IndexingError: Unalignable boolean Series`.

---

## 4. team_files

Аналог `manager_analytics.team_files` в `config.json`, но в **корне** config v2.

Единый комплект `files` + колонка **«Тип команды»** (`1` — лид, `2` — сделка, `-`+ТН `-` — не взят в работу). Legacy `lead_team` / `deal_team` — только если `files` для mode пуст (например, test).

```json
"team_files": {
  "enabled": true,
  "files": {
    "test": ["Кбан К Л и С  (А 2Т2Г) __ 07-09-2026.xlsx"],
    "prod": [
      "Канбан ЕФС1 команда лида и сделки ЮЗБ (Активы-НКД-Пассивы-ФОТ) __08-09-2026.xlsx",
      "… файлы по ТБ (ЕФС0/ЕФС1) — полный список в config_excel_v2.json …",
      "Канбан ЕФС0 команда лида и сделки ЮЗБ __08-09-2026.xlsx"
    ]
  },
  "lead_team": { "test": ["тест Команда л 2Т2Г на 31-08-2026.xlsx"], "prod": [] },
  "deal_team": { "test": ["тест Команда с 2Т2Г на 31-08-2026.xlsx"], "prod": [] },
  "team_type_values": { "lead": [1, "1"], "deal": [2, "2"], "unassigned": ["-", "—", ""] },
  "leader_values": ["Да", "да", "yes", "YES", "true", "True", "1"],
  "keep_leaders_only": true,
  "columns": { "...": "...", "team_type": "Тип команды" },
  "output_columns": {
    "lead": {
      "member_tab_number": "TN Лидера лида",
      "member": "ФИО Лидера лида",
      "role": "Роль Лидера лида",
      "tb": "ТБ Лидера лида"
    },
    "deal": { "...": "..." }
  }
}
```

- `keep_leaders_only: true` (по умолчанию) — сразу после чтения каждого файла команды остаются только строки с `Лидер` ∈ `leader_values`. Участники без флага «Лидер» в Excel v2 **нигде не используются** (lookup → снимок/почты/своды); отсев безопасен и снижает RAM до concat.
- После склейки `files` строки делятся по «Тип команды»; лидер — `Лидер` ∈ `leader_values` на max(`Дата отчета`), затем max(`Дата добавления в команду`); если `Дата отчета` нет — весь файл считается одной датой отчёта (не ошибка), дальше обычный отбор по дате добавления; равные даты — все через `\n`.
- Отсутствие любого файла из списка — ошибка.
- Если нет лидеров (в т.ч. Тип/ТН = «-») — в своде менеджеров используются **КМ** (роль «ВКО») и **ВКС** из канбана.

### Проверка входных файлов

Перед обработкой — та же логика, что в [CONFIG.md](CONFIG.md) §3: все Kanban + team_files для `mode` должны лежать в `IN/TEST` или `IN/PROD`. Иначе pipeline останавливается.

### manager_emails

CSV со справочником почт (лежит в `IN/`, имя в config). По нормализованному ТН (8 знаков с ведущими нулями) подтягиваются **Почта Альфа** и **Почта Сигма** к лидеру лида и лидеру сделки. Несколько ТН в ячейке — почты в том же порядке через `\n`. Нет файла — предупреждение, колонки пустые.

```json
"manager_emails": {
  "enabled": true,
  "directory": "IN",
  "filename": "PROM_ALPHA_gamification-statistics.csv",
  "delimiter": ";",
  "encoding": "utf-8-sig",
  "columns": {
    "tab_number": "Табельный номер",
    "email_alpha": "Почта Альфа",
    "email_sigma": "Почта Сигма"
  },
  "output_columns": {
    "lead": {
      "email_alpha": "Почта Альфа Лидера лида",
      "email_sigma": "Почта Сигма Лидера лида"
    },
    "deal": {
      "email_alpha": "Почта Альфа Лидера сделки",
      "email_sigma": "Почта Сигма Лидера сделки"
    }
  }
}
```

На листах «Свод по менеджеру» почты вставляются сразу после «ФИО»; на «Уникальные ID» — сразу после «ФИО Лидера …»; на «Свод ПрПр…» — после «Табельный номер».

### output.statistics

Управление экспортом min/max/перцентилей (расчёт всегда полный). По умолчанию: число лидов — да; min/max — нет; P20/P50 — только граница; P80 — граница + le/gt/min/max. См. [CONFIG.md](CONFIG.md).

---

## 5. output — листы и колонки

### report_parts

Какие выходные файлы строить и какие тяжёлые этапы запускать.

```json
"output": {
  "report_parts": "both",
  "report_part_suffixes": {
    "analytics": "analytics",
    "detail": "detail"
  },
  "report_prefix": "kanban_excel_v2",
  "timestamp_format": "%Y%m%d_%H%M%S"
}
```

| Значение `report_parts` | Файлы | Что **считается** | Что **пропускается** |
|-------------------------|-------|-------------------|----------------------|
| `both` (default) | analytics + detail | полный pipeline | — |
| `analytics` | `*_analytics_*.xlsx` | фильтры, records, нормативы, воронка, матрицы сроков | загрузка команд, почты, exceedance на лидах, своды менеджеров, лист Уникальные ID |
| `detail` | `*_detail_*.xlsx` | фильтры, снимок, команды, почты, нормативы→P80, exceedance, своды, колонки сроков по статусам | матрицы сроков, лист «Статистика» / воронка на экспорт |

Допустимы список `["analytics","detail"]` и синонимы (`нормативы`, `лиды`, `1`/`2`, `оба`).

Имена файлов: `{report_prefix}_{suffix}_{timestamp}.xlsx`.

> **Зачем:** на prod матрицы и воронка тяжелее по CPU; команды/почты — по I/O. Если нужна только одна часть — ставьте `analytics` или `detail`.

### sheets

```json
"sheets": {
  "norms": "Нормативы",
  "statistics": "Статистика",
  "duration_matrix": "Распределение сроков",
  "duration_matrix_by_group": "Распределение сроков (группы)",
  "duration_matrix_by_status": "Распределение сроков (статус)",
  "duration_matrix_by_group_status": "Распред. сроков (группы+статус)",
  "leads": "Уникальные ID",
  "managers": "Свод по менеджеру",
  "violations": "Свод ПрПр с отклонениями"
}
```

| Ключ | Назначение |
|------|------------|
| `norms` | Таблица нормативов + колонки **входных фильтров** и **выбросов** по строке группы; закрепление через `sheet_freeze.norms` (колонка «Уровень анализа» не выводится) |
| `statistics` | Воронка фильтров и свод отсечений (отдельное оформление: два блока) |
| `duration_matrix` | Матрица числа лидов по сроку (дни); см. блок `output.duration_matrix` ниже |
| `duration_matrix_by_group` | Второй лист той же матрицы с раскладкой `group_alpha_product_volume` (через `variants`) |
| `duration_matrix_by_status` | Матрица с разрезом по «Текущий статус» (колонка после продукта) |
| `duration_matrix_by_group_status` | Группы А→Я + статус; имя листа ≤31 символа |
| `leads` / `managers` / `violations` | См. §1 |

### sheet_freeze

По каждому ключу листа из `sheets` задаётся **последняя закреплённая** строка и столбец.
Excel закрепляет всё слева и выше первой незакреплённой ячейки.

| Поле | Смысл |
|------|--------|
| `last_row` | Последняя зафиксированная строка (`1` = шапка) |
| `last_col` | Последний зафиксированный столбец (`0` = не фиксировать; `3` или `"C"` = A–C) |

```json
"sheet_freeze": {
  "default": { "last_row": 1, "last_col": 0 },
  "norms": { "last_row": 1, "last_col": 3 },
  "duration_matrix": { "last_row": 3, "last_col": 6 },
  "duration_matrix_by_group": { "last_row": 3, "last_col": 6 },
  "duration_matrix_by_status": { "last_row": 3, "last_col": 7 },
  "duration_matrix_by_group_status": { "last_row": 3, "last_col": 7 },
  "leads": { "last_row": 1, "last_col": 3 },
  "managers": { "last_row": 1, "last_col": 2 }
}
```

Примеры: `1` / `0` → freeze `A2`; `1` / `3` → шапка + A–C (после «Продукт»); `1` / `2` → шапка + A–B (после «ФИО»).
Листы со статусом: `last_col: 7` (группа + продукт + статус + P20/P50/P80 + Всего).

### duration_matrix

Лист строится по **снимку уникальных лидов** (после входных фильтров): текущий срок `_days_on_stage` (целые дни).
Агрегация кешируется отдельно для variants без статуса и со статусом (`include_status`).

| Ось | Содержание |
|-----|------------|
| Строки | «Группа продукта», «Продукт»[, «Текущий статус»] — по `sort_mode` |
| Колонки слева | После «Продукт» [и статуса]: **P20 / P50 / P80** (только значение в днях) → **«Всего»** → дни |
| Процентили | Пересчёт по лидам строки, **все стадии вместе**; те же `percentiles`, что в config |
| Строка 2 | Горизонталь «Всего» — сумма лидов по каждому дню + общий итог |
| Столбцы дней | Целые дни, где есть **хотя бы один** лид |
| Ячейка дней | Число лидов с этим сроком; **0 и пусто не пишутся** |
| Выделение | День = `exceedance.percentile` (сейчас P50) для строки — жирная сплошная граница (`threshold_border_color`) |
| Оформление | Тонкая светло-серая пунктирная граница ячеек; шапка/продукты — бледно-жёлтый; закрепление до «Всего» |

```json
"duration_matrix": {
  "enabled": true,
  "sort_mode": "by_volume",
  "variants": [
    { "sheet_key": "duration_matrix", "sort_mode": "by_volume", "include_status": false },
    {
      "sheet_key": "duration_matrix_by_group",
      "sort_mode": "group_alpha_product_volume",
      "include_status": false
    },
    {
      "sheet_key": "duration_matrix_by_status",
      "sort_mode": "by_volume",
      "include_status": true
    },
    {
      "sheet_key": "duration_matrix_by_group_status",
      "sort_mode": "group_alpha_product_volume",
      "include_status": true
    }
  ],
  "total_column_label": "Всего",
  "day_column_width": 4.5,
  "percentile_column_width": 8,
  "grid_border_color": "BFBFBF",
  "threshold_border_color": "C65911",
  "…"
}
```

| Ключ | По умолчанию | Описание |
|------|--------------|----------|
| `enabled` | `true` | Выключить лист без удаления ключа из `sheets` |
| `sort_mode` | `by_volume` | Режим основного листа, если `variants` нет |
| `variants` | — | Список `{sheet_key, sort_mode, include_status?}`: несколько листов |
| `include_status` | `false` | В variant: колонка текущего статуса после продукта |
| `max_day_span` | `3000` | Лимит числа колонок дней |
| `row_height` | `28` | Высота строк продуктов |
| `counts_font_size` | `14` | Размер шрифта чисел лидов (ячейки и «Всего») |
| `grid_border_color` | `BFBFBF` | Цвет пунктирной границы |
| `threshold_border_color` | `C65911` | Цвет жирной рамки ячейки порога превышения |

**Режимы `sort_mode`:**

| Режим | Дни | Строки |
|-------|-----|--------|
| `alpha_days` | по возрастанию | группы и продукты А→Я |
| `by_volume` | по убыванию числа лидов (при равенстве — меньший день левее) | сверху максимум лидов |
| `group_alpha_product_volume` | по возрастанию | группы А→Я; внутри группы продукты по убыванию лидов |

### Колонки отсечения на листе «Нормативы»

В конце каждой строки группы (после перцентилей):

| Внутренний ключ | Заголовок (по умолчанию) | Смысл |
|-----------------|--------------------------|--------|
| `filter_before` | До отсечения | Уник. лиды в группе **до** всех входных фильтров |
| `filter_dropped_<имя>` | Отсечено: `<имя>` | Уник. лиды, отсечённые этим фильтром (include/exclude) |
| `filter_after` | После фильтров | Уник. лиды в группе **после** всех входных фильтров |
| `outlier_before` | До выбросов | Записи группы до правил `outlier_clipping` |
| `outlier_rule_<имя>` | Отсечено: `<имя>` | Отсечено правилом выбросов |
| `outlier_after` | После отсечения | Записи группы после всех правил выбросов |
| `outlier_clipped_total` | Отсечено выбросами (всего) | Сумма отсечений выбросов в группе |

Суммы по всем группам дублируются на листе «Статистика».

### snapshot_columns

Поля снимка уникальных `ID ПрПр` (fill-forward по max `Дата отчета`). Порядок колонок на листе = порядок ключей в блоке.

| Ключ config | Заголовок Excel (типичный) |
|-------------|----------------------------|
| `product_group` | Группа продукта |
| `product` | Продукт |
| `current_status` | Стадия работы с лидом |
| `inn` | ИНН |
| `client_id` | Идентификатор клиента (**текст**) |
| `client` | Клиент |
| `work_start_date` | Дата начала работы (`YYYY-MM-DD`) |
| `deal_id` | ID сделки |
| `deal_created_date` | Дата создания сделки (`YYYY-MM-DD`) |
| `deal_stage` | Текущая стадия сделки |
| `tb` | ТБ |
| `gosb` | ГОСБ |
| `km` | КМ |
| `vks` | ВКС |

**Не включать** в `snapshot_columns`: `source_deal_id`, `tb_code` — в отчёт не выводятся.

После «Стадия работы с лидом» автоматически вставляются колонки из [`status_duration_columns`](#status_duration_columns), затем колонки превышения и лидеров команд.

### status_duration_columns

На листе **«Уникальные ID»** (файл **detail**) после «Стадия работы с лидом» — колонки по вариантам «Текущий статус».

- **Заголовок колонки** = имя статуса  
- **Значение** = срок лида на этой стадии (целые дни)  
- **Пусто**, если лид на статусе не найден / срока нет  

```json
"status_duration_columns": {
  "enabled": true,
  "include_others": true,
  "others_sort": "alpha",
  "order": [
    "К продаже",
    "Выявление потребности",
    "Обсуждение условий",
    "Реализация сделки",
    "Активация продукта",
    "Продажа завершена"
  ]
}
```

| Ключ | По умолчанию | Описание |
|------|--------------|----------|
| `enabled` | `true` | Выключить колонки без удаления блока |
| `order` | см. выше | Канонический порядок; колонки **всегда** в шапке (даже если в данных статуса не было) |
| `include_others` | `true` | После `order` — остальные статусы из данных |
| `others_sort` | `alpha` | Сортировка прочих: А→Я |

Источник: `lead_stage_records` (уровень `status`). Несколько продуктов/ТБ у одного лида на одной стадии → **max** дней. Имена статусов сопоставляются **без учёта регистра** (`К ПРОДАЖЕ` = `К продаже`).

### exceedance / exceedance_columns

Порог превышения задаётся в корневом блоке:

```json
"exceedance": { "percentile": 80 }
```

Значение должно входить в `percentiles`. Для медианы: `"percentile": 50`.

| Ключ | Заголовок | Описание |
|------|-----------|----------|
| `p80_norm` | `Норматив P{p}` | Порог по ТБ лида (fallback — «все тб»); `{p}` → число из `exceedance.percentile` |
| `current_days` | Текущий срок | Дни на стадии (актуальная дата отчёта) |
| `exceedance_flag` | превышение | `ДА` при превышении, иначе пусто |
| `exceedance_days` | дней отклонения | Текущий срок − норматив |

### excel_format

Те же правила, что в `config.json` → `output.excel_format`:

- `freeze_panes: A2` в `excel_format` — fallback, если нет `sheet_freeze`
- `sheet_freeze` — закрепление **по листам** (`last_row` / `last_col`), см. выше
- автофильтр, ширина колонок
- `date_format: "YYYY-MM-DD"` — колонки дат (`Дата начала работы`, `Дата создания сделки`, …) пишутся как даты Excel
- `hotspots_column_width: 55` — многострочные колонки (лидеры, «Группа + Продукт», «Клиент»)
- `thousands_format: "# ##0"` — разделитель разрядов (пробел) для чисел на листе **«Статистика»**

#### Текстовые идентификаторы

«Идентификатор клиента» (и связанные ID) читаются и пишутся как **текст** (`number_format=@`), чтобы длинные значения не обрезались в Excel как числа.

В `snapshot_columns` **не выводятся** `source_deal_id` (ID сделки в исходной системе) и `tb_code` (Код ТБ).

#### `excel_theme` и `light_format_sheets`

Тема `green_red` **не отключена глобально**. В `format_sheet` заголовки, содержащие маркеры `min_header_marker` / `max_header_marker` (по умолчанию «Мин» / «Макс»), получают заливку из `excel_format.colors` (зелёный / красный). Пример на «Нормативах»: **«Мин срок дней»**, **«Макс срок дней»**.

| Лист (ключ) | `green_red` min/max | Полное поклеточное оформление |
|-------------|---------------------|-------------------------------|
| `norms`, `managers`, … | да | да |
| `leads`, `violations` (список `light_format_sheets`) | **нет** | только даты/`@` для ID + freeze / автофильтр / шапка / ширина |
| `duration_matrix*` | своё оформление листа матрицы | не через `format_sheet` |
| `statistics` | своё оформление | не через `format_sheet` |

```json
"excel_format": {
  "light_format_sheets": ["leads", "violations"],
  "colors": { "min": "C6EFCE", "max": "FFC7CE" }
}
```

`light_format_sheets` ускоряет экспорт ПРОД на больших листах: без обхода каждой ячейки для заливки и number_format.

### Большие листы → CSV

Если на листе **больше** `excel_max_rows_per_sheet` строк данных (по умолчанию **900 000**), вкладка в xlsx **не создаётся** — данные пишутся в отдельный CSV рядом с отчётом:

`kanban_excel_v2_{timestamp}_{Имя листа}.csv`

| Ключ | По умолчанию | Описание |
|------|--------------|----------|
| `excel_max_rows_per_sheet` | `900000` | Порог строк (лимит Excel ~1 048 576) |
| `csv_overflow.enabled` | `true` | Включить выгрузку в CSV |
| `csv_overflow.delimiter` | `";"` | Разделитель полей |
| `csv_overflow.encoding` | `utf-8-sig` | Кодировка (BOM для Excel в Windows) |

Если **все** листы ушли в CSV, в xlsx остаётся служебный лист «Экспорт CSV» со списком файлов.

### percentile_column_labels

Подписи перцентилей на листе «Нормативы» (`П20 дней`, `П20 лидов ≤`, …).

---

## 6. client_display

Сокращение полных юрформ в колонке «Клиент» (ООО, АО, **СЗ** и др.).  
Правила — от длинной формы к короткой; замена только префикса, остаток названия сохраняется.

```json
{"match": "специализированный застройщик", "replace": "СЗ"}
```

`enabled: false` — выводить исходный текст из Excel.

---

## 7. Производительность

| Ключ | По умолчанию | Описание |
|------|--------------|----------|
| `parallel_workers` | `0` | Параллельная загрузка Kanban-файлов (`ProcessPoolExecutor`) |
| `performance.max_parallel_workers` | `4` | Потолок workers |
| `performance.reserve_cpu_cores` | `1` | Ядра, оставляемые системе |
| `performance.read_only_required_columns` | `true` | Читать только нужные колонки |
| `performance.downcast_numeric` | `true` | Сжатие типов флагов |
| `performance.free_memory_between_stages` | `true` | `gc.collect()` между этапами |
| `performance.parallel_pipeline_stages` | `true` | Параллельно: снимок + трекинг стадий + загрузка команд |
| `performance.parallel_stage_workers` | `0` | Workers для параллельных этапов (`0` = как `parallel_workers`) |

### `performance.adaptive_resources`

| Ключ | По умолчанию | Описание |
|------|--------------|----------|
| `enabled` | `true` | Мониторинг RAM и автоснижение workers (см. `CONFIG.md` §8) |
| `min_available_ram_gb` | `3.0` | Порог warn (ГБ свободной RAM) |
| `critical_available_ram_gb` | `1.5` | Порог critical |
| `sequential_load_below_total_ram_gb` | `16.0` | При общей RAM &lt; порога — осторожный режим |
| `low_ram_max_workers` | `2` | Потолок workers в осторожном режиме |
| `warn_max_workers` | `2` | Потолок workers при warn |
| `critical_max_workers` | `1` | Потолок workers при critical |
| `gc_on_pressure` | `true` | `gc.collect()` между файлами при warn/critical |
| `override_explicit_workers_on_critical` | `true` | Ограничение явного `parallel_workers` при critical |

При `parallel_pipeline_stages: true` одновременно выполняются:

1. `build_lead_snapshot` (CPU)
2. `build_lead_stage_records` (CPU)
3. загрузка «Команда лида и сделки» (I/O, единый комплект + split по типу)
4. ~~загрузка «Команда сделки»~~ (входит в п.3)

---

## 8. Минимальный config

```json
{
  "mode": "test",
  "test_files": ["тест Канбан 2Т2Г (ALL) на 31-08-2026.xlsx"],
  "output": {
    "report_parts": "both"
  }
}
```

Остальное дополняется из `src/settings.py` (`normalize_config`).  

Типичные переключатели без правки кода:

| Задача | Ключ |
|--------|------|
| Только нормативы и матрицы | `"report_parts": "analytics"` |
| Только уникальные ID / менеджеры | `"report_parts": "detail"` |
| Порог превышения = медиана | `"exceedance": { "percentile": 50 }` |
| Порядок статусов на «Уникальные ID» | `output.status_duration_columns.order` |
| Формат дат | `output.excel_format.date_format` (`YYYY-MM-DD`) |

Для листов менеджеров нужны файлы команд в `team_files` и колонки `km` / `vks` в Kanban.

---

## Связанные документы

- [README.md](../README.md) — обзор, запуск `run_excel.py`
- [CONFIG.md](CONFIG.md) — справочник `config.json` (HTML+JSON pipeline)
- [DEPLOY.md](DEPLOY.md) — перенос на другой ПК
- [ROADMAP.md](../ROADMAP.md) — Фаза 11
- [Docs/ToDo KANBAN v2.txt](ToDo%20KANBAN%20v2.txt) — исходное ТЗ